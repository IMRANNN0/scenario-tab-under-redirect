import test from 'node:test';import assert from 'node:assert/strict';
import {createOfferRouter,validateDestinations} from '../../../offer-tab-router/assets/router.mjs';
const config={offerUrl:'https://offer.example.test/path?click_id=original',bUrl:'/b'};
const event=()=>({isTrusted:true,button:0,preventDefault(){this.defaultPrevented=true;}});
function setup({blocked=false,throwNavigation=false}={}){const assigned=[],tab={opener:{},location:{replace:url=>assigned.push(['offer',url])},close(){}};const win={location:{href:'https://prelander.example.test/a',assign:url=>{if(throwNavigation)throw Error();assigned.push(['original',url]);}},open:()=>blocked?null:tab};return {win,assigned,tab};}
test('new tab retains tracker URL and only then requests B',()=>{const s=setup(),r=createOfferRouter({...config,win:s.win});assert.equal(r.route(event(),{eventId:'id'}).status,'new-tab-requested');assert.equal(s.tab.opener,null);assert.deepEqual(s.assigned,[['offer',config.offerUrl],['original','https://prelander.example.test/b']]);assert.equal(r.route(event(),{eventId:'id'}).status,'duplicate');});
test('popup blocked uses same-tab offer without B',()=>{const s=setup({blocked:true}),r=createOfferRouter({...config,win:s.win});const result=r.route(event(),{eventId:'id'});assert.equal(result.status,'same-tab-requested');assert.equal(result.bRequested,false);assert.deepEqual(s.assigned,[['original',config.offerUrl]]);});
test('a distinct genuine action can open another offer while the same ID cannot',()=>{
  const s=setup(),r=createOfferRouter({offerUrl:config.offerUrl,win:s.win});
  assert.equal(r.route(event(),{eventId:'first'}).status,'new-tab-requested');
  assert.equal(r.route(event(),{eventId:'first'}).status,'duplicate');
  assert.equal(r.route(event(),{eventId:'second'}).status,'new-tab-requested');assert.equal(s.assigned.length,2);
});
test('B navigation failure does not permit a duplicate offer for the same action',()=>{
  const s=setup({throwNavigation:true}),r=createOfferRouter({...config,win:s.win});
  assert.equal(r.route(event(),{eventId:'first'}).status,'b-navigation-failed');
  assert.equal(r.route(event(),{eventId:'first'}).status,'duplicate');assert.equal(s.assigned.length,1);
});
test('same-tab mode and no-B option work independently',()=>{const s=setup();createOfferRouter({...config,mode:'same-tab',win:s.win}).route(event(),{eventId:'id'});assert.deepEqual(s.assigned,[['original',config.offerUrl]]);const t=setup();createOfferRouter({offerUrl:config.offerUrl,win:t.win}).route(event(),{eventId:'id'});assert.equal(t.assigned.length,1);});
test('programmatic/modifier activations do not hijack navigation',()=>{for(const props of [{isTrusted:false},{ctrlKey:true},{metaKey:true},{shiftKey:true},{altKey:true},{button:1},{defaultPrevented:true}]){const s=setup(),r=createOfferRouter({...config,win:s.win});assert.equal(r.route({...event(),...props},{eventId:'id'}).status,'not-handled');assert.equal(s.assigned.length,0);}});
test('tracking exceptions do not block route and navigation failure is explicit',()=>{const s=setup();const r=createOfferRouter({...config,win:s.win,onRequested:()=>{throw Error();}});assert.equal(r.route(event(),{eventId:'id'}).status,'new-tab-requested');const t=setup({blocked:true,throwNavigation:true});assert.equal(createOfferRouter({...config,win:t.win}).route(event(),{eventId:'id'}).status,'navigation-failed');});
test('invalid destinations and cross-origin B fail before opening',()=>{for(const offerUrl of ['javascript:alert(1)','data:text/html,hi','http://offer.example.test','https://u:p@offer.example.test',''])assert.throws(()=>validateDestinations({offerUrl,base:'https://example.test'}));assert.throws(()=>validateDestinations({offerUrl:config.offerUrl,bUrl:'https://other.test',base:'https://example.test'}));});
